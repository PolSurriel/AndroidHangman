package com.example.enti_di_unica_pol_surriel.model

/**
 * Model for the keyboard UI of the game scene
 * */
data class KeyboardLetter (val letter:String, var pressed : Boolean = false)