package com.example.enti_di_unica_pol_surriel.model

/**
 * Model for the user score list UI
 * */
data class UserScore (val score:Int = 0, val userName:String = "")